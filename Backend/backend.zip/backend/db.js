const mysql = require('mysql2');

// Configurar conexão MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'tc_brasil'
});

db.connect((err) => {
    if (err) {
        console.error("Erro ao conectar com o banco:", err);
    } else {
        console.log("MySQL conectado com sucesso!");
    }
});

module.exports = db;